<p align="center">
  <img src="https://img.shields.io/badge/Autism-Acceptance-gold?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAgNjAiPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAlIiB5MT0iMCUiIHgyPSIxMDAlIiB5Mj0iMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiNFODVDNUMiLz48c3RvcCBvZmZzZXQ9IjUwJSIgc3RvcC1jb2xvcj0iIzdCQzc0RCIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI0E5N0NEQiIvPjwvZGVmcz48cGF0aCBkPSJNNjAsMzAgQzYwLDEzIDczLDIgODcsMiBDMTAxLDIgMTE0LDEzIDExNCwzMCBDMTE0LDQ3IDEwMSw1OCA4Nyw1OCBDNzMsNTggNjAsNDcgNjAsMzAgQzYwLDQ3IDQ3LDU4IDMzLDU4IEMxOSw1OCA2LDQ3IDYsMzAgQzYsMTMgMTksMiAzMywyIEM0NywyIDYwLDEzIDYwLDMwWiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI2cpIiBzdHJva2Utd2lkdGg9IjUiLz48L3N2Zz4="/>
</p>

<h1 align="center">♾️ BrightPath</h1>
<p align="center"><strong>Learning made for every mind</strong></p>
<p align="center">An autism-friendly learning platform with AI, speech therapy, games, and parent tools</p>

<p align="center">
  <img src="https://img.shields.io/badge/Games-12×15_Levels-4ECDC4?style=flat-square"/>
  <img src="https://img.shields.io/badge/Screens-22-FF8C42?style=flat-square"/>
  <img src="https://img.shields.io/badge/AI-Claude_Powered-A97CDB?style=flat-square"/>
  <img src="https://img.shields.io/badge/License-MIT-7BC74D?style=flat-square"/>
</p>

---

## ✨ What is BrightPath?

BrightPath is a comprehensive autism-friendly learning platform that teaches the learner **AND** the people around them. Built for people of all ages and abilities, it combines interactive games, speech therapy, daily living tools, and a full parent education center into one app.

**We use the rainbow infinity symbol ♾️ because we celebrate neurodiversity.**

---

## 🎮 Features

### For Learners
| Feature | Description |
|---------|-------------|
| 🧠 **12 Games × 15 Levels** | Memory, Bubbles, Feelings, Sequence, Spelling, Math, Patterns, Social Skills, Odd One Out, Color Sort, ABCs, Time & Days |
| 🗣️ **Speech Therapy** | 4 progressive levels with phonetic guides, mouth shape visuals, text-to-speech, and microphone recognition |
| 🤖 **AI Buddy** | Claude-powered learning companion with offline fallback (never shows errors) |
| 🖼️ **Picture Cards** | 48+ visual cards across Emotions, Animals, Food, and Actions with tap-to-speak |
| 📖 **Social Stories** | Step-by-step visual narratives for real situations (doctor visits, school, meeting people) |

### For Daily Living
| Feature | Description |
|---------|-------------|
| 🧘 **Calm Corner** | Breathing exercises, rain animation, starfield, 5-4-3-2-1 grounding |
| 💬 **AAC Board** | Tap-to-speak picture communication for non-verbal/pre-verbal users |
| 📋 **Visual Schedule** | Customizable daily routine builder with 18 preset activities |
| ⏳ **Transition Timer** | Visual countdown circle for smoother transitions |
| 🌡️ **Feelings Thermometer** | 5-level emotion scale with matched coping strategies |
| 🔄 **First-Then Board** | Visual motivation tool used in ABA therapy |

### For Parents & Caregivers
| Module | Lessons |
|--------|---------|
| 📘 **Communication Fundamentals** | How autism affects language, what doesn't work, what to do instead |
| 🌊 **Meltdowns: What to Do** | Warning signs, during, and after — evidence-based strategies |
| 🔊 **Understanding Sensory Needs** | Hyper/hypo sensitivity, creating sensory-safe spaces |
| 📋 **Routines & Transitions** | Why predictability matters, managing change |
| 🗣️ **Supporting Speech** | AAC, encouraging communication, working with therapists |
| 🤝 **Social Skills at Home** | Rethinking social skills, practical support, handling bullying |
| 💛 **Caregiver Self-Care** | Burnout prevention, building your support network |

### Platform Features
- 👤 **Persistent Profiles** — Multiple learner profiles with stars and progress tracking
- 👑 **Subscription Tiers** — Free, Plus ($9.99/mo), Family ($19.99/mo) with real feature gating
- ♿ **Accessibility** — Dark mode, calm mode (no animations), large text, adjustable speech speed
- 🔧 **Self-Healing Media** — Automatically detects broken YouTube links and redirects to search
- 🛡️ **Error Boundary** — Catches any crash with friendly recovery screen
- ♾️ **Autism Branding** — Rainbow infinity symbol, gold acceptance colors, neurodiversity messaging

---

## 🚀 Getting Started

### Run as React Component
The app is a single React JSX file that can be rendered in any React environment:

```jsx
import App from './App.jsx';

// Render in your React app
<App />
```

### Requirements
- React 18+
- `window.storage` API (for persistent data) or `localStorage` polyfill
- Internet connection for AI (falls back to offline responses)
- Microphone access for speech therapy (optional)

---

## 📊 Technical Details

```
Lines of code:     439
Screens:           22
Games:             12 × 15 levels = 180 modes
YouTube videos:    16 (age-filtered)
Music tracks:      8
Speech exercises:  23
Picture cards:     48+
Social stories:    4 × 5-6 steps
Parent modules:    7 (17 lessons, 85+ strategies)
Math generation:   Procedural (unlimited)
```

### Architecture
- **Single-file React component** with hooks (no class components except ErrorBoundary)
- **Persistent storage** via `window.storage` API with key-value pairs
- **AI** via Anthropic Claude API with comprehensive offline fallback
- **Media** opens YouTube in new tab (not embedded, to avoid iframe restrictions)
- **Self-healing** checks all YouTube thumbnails on load, auto-redirects broken links
- **Error boundary** wraps entire app, catches any runtime crash

---

## 🛣️ Roadmap to App Store

See [LAUNCH-GUIDE.md](LAUNCH-GUIDE.md) for the complete step-by-step guide including:
- Converting to React Native
- Integrating real subscriptions (RevenueCat)
- COPPA compliance for children's apps
- Apple App Store & Google Play submission
- Pricing strategy and cost estimates

---

## 🤝 Contributing

Contributions are welcome! Areas where help is needed:
- React Native conversion
- Additional game types
- More languages (i18n)
- Accessibility improvements
- Real-world testing with autistic users and families

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

## 💛 Acknowledgments

- Built with love for the autism community
- Uses the rainbow infinity symbol ♾️ — the neurodiversity symbol chosen BY autistic people
- Music section features autistic artists: Owl City (Adam Young), Kodi Lee
- Parent center content informed by evidence-based practices from ABA, speech therapy, and occupational therapy research

---

<p align="center">
  <strong>♾️ Every mind has its own beautiful path</strong>
</p>
